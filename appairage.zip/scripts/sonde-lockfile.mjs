#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { request } from 'node:https';

/**
 * Sonde de l'API locale du client Riot — Brique 9, etape zero.
 *
 * POURQUOI CE SCRIPT EXISTE
 *
 * Toute la brique 9 repose sur une hypothese : le client Riot expose en local
 * assez d'informations pour detecter une fin de partie a la seconde et pour
 * prouver quel compte est connecte. Batir une application Tauri avant d'avoir
 * verifie ca, ce serait des semaines de travail sur un pari.
 *
 * Ce script ne fait donc qu'une chose : regarder ce qui est reellement
 * disponible sur CETTE machine, et le dire.
 *
 * CE QU'IL FAIT, ET CE QU'IL NE FAIT PAS
 *
 *   - Il LIT le fichier lockfile que le client Riot ecrit lui-meme, et
 *     interroge son serveur HTTP local. C'est ce que font tous les outils
 *     communautaires de ce genre.
 *   - Il n'injecte rien, ne s'accroche a aucun processus, ne modifie aucun
 *     fichier du jeu et n'envoie aucune requete aux serveurs de Riot. Il ne
 *     touche pas au jeu : uniquement au client, et en lecture.
 *
 * A savoir quand meme : ces routes locales ne sont pas documentees par Riot et
 * peuvent disparaitre du jour au lendemain. Rien de ce qui suit n'est un
 * engagement de leur part.
 *
 * UTILISATION
 *   Lance le client Riot (et Valorant si tu veux tester en partie), puis :
 *     node scripts/sonde-lockfile.mjs
 *
 * Les secrets affiches sont tronques : le rapport est fait pour etre partage.
 */

const LOCKFILE = join(
  process.env.LOCALAPPDATA ?? join(homedir(), 'AppData', 'Local'),
  'Riot Games', 'Riot Client', 'Config', 'lockfile',
);

/** Tronque un secret pour qu'il reste identifiable sans etre utilisable. */
const masque = (s) => (typeof s === 'string' && s.length > 12
  ? `${s.slice(0, 6)}…${s.slice(-4)} (${s.length} car.)`
  : '(absent)');

/**
 * Appel HTTPS local.
 *
 * On passe par node:https et pas par fetch() : le serveur du client Riot
 * presente un certificat auto-signe — il n'existe aucune autorite qui puisse
 * signer un certificat pour 127.0.0.1 — et le fetch global de Node ignore
 * purement et simplement l'option qui permettrait de l'accepter. La verification
 * n'est donc levee QUE pour cette connexion locale, jamais globalement.
 */
function requeteLocale(options) {
  return new Promise((resoudre, rejeter) => {
    const req = request({ ...options, rejectUnauthorized: false }, (res) => {
      let corps = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { corps += c; });
      res.on('end', () => resoudre({ status: res.statusCode, corps }));
    });
    req.on('error', rejeter);
    req.setTimeout(5000, () => { req.destroy(new Error('délai dépassé')); });
    req.end();
  });
}

async function lireLockfile() {
  const brut = await readFile(LOCKFILE, 'utf8');
  const [name, pid, port, password, protocol] = brut.trim().split(':');
  return { name, pid, port, password, protocol };
}

function fabriqueAppel({ port, password }) {
  const auth = Buffer.from(`riot:${password}`).toString('base64');

  return async function appel(chemin) {
    let res;
    try {
      res = await requeteLocale({
        host: '127.0.0.1', port: Number(port), path: chemin, method: 'GET',
        headers: { Authorization: `Basic ${auth}` },
      });
    } catch (err) {
      return { ok: false, status: 0, corps: err.message };
    }

    if (res.status < 200 || res.status >= 300) {
      return { ok: false, status: res.status, corps: res.corps.slice(0, 200) };
    }
    try {
      return { ok: true, status: res.status, data: JSON.parse(res.corps) };
    } catch {
      return { ok: true, status: res.status, data: res.corps.slice(0, 200) };
    }
  };
}

/** Le detail utile d'une presence est du JSON encode en base64 dans `private`. */
function decoderPresence(p) {
  if (!p?.private) return null;
  try {
    const d = JSON.parse(Buffer.from(p.private, 'base64').toString('utf8'));
    const garde = {};
    for (const cle of [
      'sessionLoopState', 'partyState', 'competitiveTier', 'partySize',
      'queueId', 'provisioningFlow', 'matchMap', 'isValid',
    ]) {
      if (d[cle] !== undefined) garde[cle] = d[cle];
    }
    return garde;
  } catch {
    return null;
  }
}

const titre = (t) => console.log(`\n${'─'.repeat(64)}\n${t}\n${'─'.repeat(64)}`);
const ligne = (cle, valeur) => console.log(`  ${String(cle).padEnd(28)} ${valeur}`);

async function main() {
  console.log('Sonde de l\'API locale du client Riot — lecture seule\n');

  /* --- 1. Le lockfile ---------------------------------------------------- */

  titre('1. Lockfile');
  let lock;
  try {
    lock = await lireLockfile();
    ligne('chemin', LOCKFILE);
    ligne('client', lock.name);
    ligne('pid', lock.pid);
    ligne('port', lock.port);
    ligne('protocole', lock.protocol);
    ligne('mot de passe', masque(lock.password));
  } catch (err) {
    ligne('chemin', LOCKFILE);
    console.log(`\n  ÉCHEC : ${err.code === 'ENOENT'
      ? "fichier absent — le client Riot n'est pas lancé."
      : err.message}`);
    console.log('\n  Lance le client Riot, puis relance ce script.');
    return;
  }

  const appel = fabriqueAppel(lock);

  /* --- 2. Qui est connecte ---------------------------------------------- */

  titre('2. Identite du compte connecté');
  const ent = await appel('/entitlements/v1/token');
  if (ent.ok && ent.data?.subject) {
    ligne('puuid local', ent.data.subject);
    ligne('jeton d’accès', masque(ent.data.accessToken));
    ligne('entitlements', masque(ent.data.token));
    console.log('\n  → C\'est CE puuid qui prouverait la propriété d\'un Riot ID');
    console.log('    et permettrait enfin de passer `verified` à true.');
  } else {
    ligne('résultat', `échec (HTTP ${ent.status})`);
    console.log(`  corps : ${ent.corps ?? '(vide)'}`);
  }

  /* --- 3. Valorant tourne-t-il ? ---------------------------------------- */

  titre('3. Sessions de jeu en cours');
  const ses = await appel('/product-session/v1/external-sessions');
  if (ses.ok && ses.data && typeof ses.data === 'object') {
    const entrees = Object.entries(ses.data);
    if (entrees.length === 0) {
      ligne('sessions', 'aucune — le jeu n’est pas lancé');
    }
    for (const [id, s] of entrees) {
      ligne(s.productId ?? id, `${s.exitCode === undefined ? 'en cours' : 'terminée'} · pid ${s.pid ?? '?'}`);
    }
  } else {
    ligne('résultat', `échec (HTTP ${ses.status})`);
  }

  /* --- 4. La presence : l'etat de partie en direct ----------------------- */

  titre('4. Présence (l’état de partie, en direct)');
  const pres = await appel('/chat/v4/presences');
  let etatDePartie = null;

  if (pres.ok && Array.isArray(pres.data?.presences)) {
    ligne('présences visibles', pres.data.presences.length);

    // Un meme compte a PLUSIEURS presences, une par produit. Celle du client
    // ("riot_client") ne contient aucun etat de partie : il faut celle du jeu.
    // Premiere version de ce script : elle prenait la premiere venue, donc
    // celle du client, et concluait a tort que tout allait bien.
    const miennes = pres.data.presences.filter((p) => p.puuid === ent.data?.subject);
    ligne('mes présences', miennes.map((p) => p.product ?? '?').join(', ') || 'aucune');

    const jeu = miennes.find((p) => p.product === 'valorant');
    if (!jeu) {
      ligne('présence Valorant', 'ABSENTE — le jeu n’est pas lancé');
      console.log('\n  L’état de partie ne peut pas être observé sans le jeu ouvert.');
    } else {
      etatDePartie = decoderPresence(jeu);
      if (etatDePartie) {
        console.log('\n  Contenu décodé de ma présence Valorant :');
        for (const [cle, val] of Object.entries(etatDePartie)) ligne(`  ${cle}`, JSON.stringify(val));
        console.log('\n  → sessionLoopState est la clé : MENUS / PREGAME / INGAME.');
        console.log('    Le passage INGAME → MENUS, c’est la fin de partie, à la seconde.');
      } else {
        ligne('présence Valorant', 'présente mais illisible');
      }
    }

    // Les amis : c'est ce qui permettrait de savoir qui joue, sans API externe.
    const autres = pres.data.presences.filter((p) => p.puuid !== ent.data?.subject);
    ligne('amis visibles', autres.length);
    const amisEnJeu = autres.filter((p) => p.product === 'valorant');
    ligne('dont sur Valorant', amisEnJeu.length);
    for (const a of amisEnJeu) {
      const e = decoderPresence(a);
      ligne(`  ${(a.game_name ?? a.puuid.slice(0, 8))}`, e?.sessionLoopState ?? '?');
    }
  } else {
    ligne('résultat', `échec (HTTP ${pres.status})`);
    console.log(`  corps : ${pres.corps ?? '(vide)'}`);
  }

  /* --- 5. Ce qu'on en conclut ------------------------------------------- */

  titre('5. Verdict');
  const aIdentite = Boolean(ent.ok && ent.data?.subject);
  const aListePresences = Boolean(pres.ok && pres.data?.presences);

  // Distinguer "prouve" de "pas observe" : sans le jeu ouvert, l'etat de partie
  // n'est pas absent, il n'a simplement pas pu etre teste.
  ligne('preuve de compte (verified)', aIdentite ? 'PROUVÉ' : 'ÉCHEC');
  ligne('liste des présences', aListePresences ? 'PROUVÉ' : 'ÉCHEC');
  ligne(
    'état de partie en direct',
    etatDePartie?.sessionLoopState
      ? `PROUVÉ (${etatDePartie.sessionLoopState})`
      : 'NON OBSERVÉ — relance avec Valorant ouvert',
  );

  if (aIdentite && etatDePartie?.sessionLoopState) {
    console.log('\n  Tout est vérifié. La brique 9 tient debout.');
  } else if (aIdentite && aListePresences) {
    console.log('\n  L’identité est prouvée, l’état de partie reste à vérifier.');
    console.log('  Lance Valorant, puis :  node scripts/sonde-lockfile.mjs --suivi');
  } else {
    console.log('\n  Une brique manque : à regarder avant d’investir dans l’app desktop.');
  }
}

/**
 * Mode suivi : interroge la presence toutes les deux secondes et n'affiche que
 * les CHANGEMENTS.
 *
 * C'est l'experience qui decide de toute la brique : lancer une partie et voir
 * defiler MENUS -> PREGAME -> INGAME -> MENUS. Si cette sequence apparait, la
 * detection de fin de partie ne passe plus jamais par HenrikDev.
 */
async function suivre() {
  console.log('Suivi de l’état de partie — Ctrl+C pour arrêter.\n');
  console.log('Lance une partie : les changements s’afficheront ici.\n');

  let lock;
  try {
    lock = await lireLockfile();
  } catch {
    console.log('Le client Riot n’est pas lancé.');
    return;
  }

  const appel = fabriqueAppel(lock);
  const ent = await appel('/entitlements/v1/token');
  const moi = ent.data?.subject;
  let precedent = null;

  const heure = () => new Date().toLocaleTimeString('fr-FR');

  setInterval(async () => {
    const pres = await appel('/chat/v4/presences');
    if (!pres.ok) return;

    const jeu = (pres.data.presences ?? []).find(
      (p) => p.puuid === moi && p.product === 'valorant',
    );
    const etat = jeu ? decoderPresence(jeu) : null;
    const cle = JSON.stringify(etat);

    if (cle === precedent) return;
    precedent = cle;

    if (!etat) {
      console.log(`${heure()}  —  Valorant fermé`);
      return;
    }
    console.log(
      `${heure()}  ${String(etat.sessionLoopState ?? '?').padEnd(8)}`
      + ` · ${etat.partyState ?? '?'}`
      + (etat.matchMap ? ` · ${etat.matchMap.split('/').pop()}` : '')
      + (etat.queueId ? ` · ${etat.queueId}` : ''),
    );
  }, 2000);
}

if (process.argv.includes('--suivi')) {
  suivre().catch((err) => { console.error(err.message); process.exitCode = 1; });
} else {
  main().catch((err) => {
    console.error('\nÉchec inattendu :', err.message);
    process.exitCode = 1;
  });
}
